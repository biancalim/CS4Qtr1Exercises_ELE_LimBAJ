/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package storesim;

/**
 *
 * @author ELECTRON
 */
import java.util.ArrayList;

    public class Store {
  private String name;
  private double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList();

  public Store(String name){
      this.name = name;
      itemList = new ArrayList();
      this.earnings = 0;
      storeList.add(this);
    // Initialize name to parameter and earnings to zero
    // Initialize itemList as a new ArrayList
    // add 'this' store to storeList
  }

  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
      if (index > itemList.size() - 1 ){
           System.out.println("There are only " + index + " items in " + this.name);
      }
      else {
           this.earnings += Item.getItem(index).getCost();
          System.out.println(this.earnings);
      }
      
    // check if index is within the size of the itemList (if not, print statement that there are only x items in the store)
    // get Item at index from itemList and add its cost to earnings
    // print statement indicating the sale
  }
  
  public void sellItem(String name){
     for (int i = 0; i < itemList.size(); i++){
         if(itemList.get(i).getName().equals(name)){
             this.earnings += itemList.get(i).getCost();
             System.out.println("Php " + earnings);
         }
         else if (i == itemList.size() && itemList.get(i).getName().contains(name)){
             System.out.println(name + " is not sold in " + this.name);
             break;
         }
     }
    // check if Item with given name is in the itemList (you will need to loop over itemList) (if not, print statement that the store doesn't sell it)
    // get Item from itemList and add its cost to earnings
    // print statement indicating the sale
  }
  public void sellItem(Item i){
      
      if(itemList.contains(i)){
          earnings += i.getCost();
          System.out.println("Php " + earnings);
      }
      else {
          System.out.println(i.getName() + " is not sold in " + this.name);
      }
    // check if Item i exists in the store (there is a method that can help with this) (if not, print statement that the store doesn't sell it)
    // get Item i from itemList and add its cost to earnings
    // print statement indicating the sale
  }
  public void addItem(Item i){
      itemList.add(i);
    // add Item i to store's itemList
  }
  public void filterType(String type){
      for (Item r : itemList){
          if (r.getType().contains(type)){
              System.out.println(r.getName());
          }
      }
    // loop over itemList and print all items with the specified type
  }
  public void filterCheap(double maxCost){
      for (Item r : itemList){
          if (r.getCost() <= maxCost){
              System.out.print(r.getName() + ' ');
          }
      }
    // loop over itemList and print all items with a cost lower than or equal to the specified value
  }
  public void filterExpensive(double minCost){
      for (Item r : itemList){
          if (r.getCost() >= minCost){
              System.out.println(r.getName() + ' ');
          }
      }
    // loop over itemList and print all items with a cost higher than or equal to the specified value
  }
  public static void printStats(){
      for (Store e : storeList){
          System.out.println(e.getName() + ": " + e.getEarnings());
      }
     
    // loop over storeList and print the name and the earnings'Store.java'

  }
}



