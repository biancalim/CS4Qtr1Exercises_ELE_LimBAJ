/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex02_ele_limbaj;

/**
 *
 * @author Bianca
 */
public class EX02_ELE_LimBAJ {

    public static void main(String[] args) {
        
        NewClass1 brand1 = new NewClass1("Shure SM57");
        NewClass1 brand2 = new NewClass1("LEWITT");
        NewClass1 brand3 = new NewClass1("Sennheiser");
       
        Song song1 = new Song("Wildest Dreams");
        Song song2 = new Song("Shake it off");

        Singer taylor = new Singer("Taylor Swift");
      
        taylor.changeFavSong(song1);
        taylor.performForAudience(12);

        System.out.println("Singer name: " + taylor.name);
        System.out.println("Favorite Song: " + taylor.favoriteSong.name);
        System.out.println("Number of Performances: " + taylor.noOfPerformances);
      System.out.println("Audience Number: " + taylor.audienceNumber);
        System.out.println("Microphone Brand: " +brand1.brand);
      

        System.out.println(' ');

        taylor.changeFavSong(song2);

        System.out.println("Singer name: " + taylor.name);
        System.out.println("Favorite Song changed to: " + taylor.favoriteSong.name);
      System.out.println("Number of Performances: " + taylor.noOfPerformances);
        System.out.println("Audience number: " + taylor.audienceNumber);
        System.out.println("Microphone Brand: " + brand2.brand + " and " + brand3.brand);


        

    }
}
