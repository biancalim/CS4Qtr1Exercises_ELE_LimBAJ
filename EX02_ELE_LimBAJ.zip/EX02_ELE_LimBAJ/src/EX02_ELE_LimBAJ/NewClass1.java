/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex02_ele_limbaj;

/**
 *
 * @author Bianca
 */
public class NewClass1 {
     String brand;
    String objectUsed;
    double budget;
    int hoursUsed;
    
    public NewClass1(String m){
        brand = m;
        objectUsed = "Microphone";
        hoursUsed = 7;
        budget = 17500.00;
    }
}
