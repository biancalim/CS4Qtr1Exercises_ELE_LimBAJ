
/*EX03_ELE_LimBAJ

*/
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package EX03_ELE_LimBAJ;

/**
 *
 * @author Bianca
 */


public class EX03_ELE_LimBAJ {
        public static void main(String[] args){
          Brands brand1 = new Brands("Shure SM57");
          Brands brand2 = new Brands("LEWITT");
          Brands brand3 = new Brands("Sennheiser");
          
          Song song1 = new Song("Wildest Dreams");
          Song song2 = new Song("Shake it off");
          
          
          Singer taylor = new Singer("Taylor Swift");
          Singer ariana = new Singer("Ariana grande");
          Singer laufey = new Singer("laufey");
          
          
          taylor.performForAudience(30);
          taylor.performForAudience(30, ariana);
          ariana.performForAudience(30, laufey);
          ariana.performForAudience(20);
          laufey.performForAudience(40);
          
          System.out.println("Singer 1: " +  taylor.getName());         
          System.out.println("Perf number: " + taylor.getNoOfPerformances()); 
          System.out.println("Singer 1's Earnings: Php " + taylor.getEarnings());

          System.out.println(' ');
          
          taylor.performForAudience(20);
          
          System.out.println("Singer 2: " +  ariana.getName());         
          System.out.println("Perf number: " + ariana.getNoOfPerformances()); 
          System.out.println("Singer 2's earnings: Php " + ariana.getEarnings());

          
          
        }

    }
    
    

