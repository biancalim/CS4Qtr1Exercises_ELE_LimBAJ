//EX03_ELE_LimBAJ output

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EX03_ELE_LimBAJ;

/**
 *
 * @author Bianca
 */
public class Singer {
    private String name;
    private Song favoriteSong;
    private int noOfPerformances;
    private double earnings;
    private Song changeFavSong;
    private static int totalPerformances;
    private double totalEarnings;
    private double actualEarning;
    
    public Singer(String s){
        name = s;
    }

    public String getName(){
      return name;
    }
    
    public void performForAudience(int audience){
        this.noOfPerformances = getNoOfPerformances() + 1;
        totalPerformances = totalPerformances + 1;
        this.earnings = earnings + (100 * audience);
    }
    
    public void performForAudience(int audience, Singer collab){
        this.noOfPerformances = getNoOfPerformances() + 1;
        collab.noOfPerformances = collab.getNoOfPerformances() + 1;
        this.earnings = earnings + (100/2) * audience;
        collab.earnings = collab.earnings + (100/2) * audience;
        totalPerformances = totalPerformances +1;
    }
    
    public static int getTotalPerformances(){
        return totalPerformances;
    }
    
    public double getEarnings(){
        return earnings;
    }
    
    public void Song(Song c){
        favoriteSong = c;
    }

    public int getNoOfPerformances() {
        return noOfPerformances;
    }

}
