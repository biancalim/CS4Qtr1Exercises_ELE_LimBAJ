//EX03_ELE_LimBAJ output

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EX03_ELE_LimBAJ;

/**
 *
 * @author Bianca
 */

//EX03_ELE_LimBAJ output
public class Song {
    String name;
    int albumNumber;
    double approxNumberOfMinutes;
          
    public Song(String s){
        name = s;
        albumNumber = 5;
        approxNumberOfMinutes = 3.60;
    }
    
    public String getName(){
        return name;
    }
    
    public int getAlbumNo(){
        return albumNumber;
    }
    
    public double getApproxMin(){
        return approxNumberOfMinutes;
    }
}

