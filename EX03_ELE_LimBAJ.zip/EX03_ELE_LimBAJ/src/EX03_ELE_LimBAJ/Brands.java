//EX03_ELE_LimBAJ output

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EX03_ELE_LimBAJ;

/**
 *
 * @author Bianca
 */
public class Brands {
            private String brand;
            private static double budget;
            private static int hoursUsed;
        
        public Brands(String b){
            brand = b;
            budget = 17500.00;
            hoursUsed = 7;
        }
        
        public String getBrand(){
            return brand;
        }
          
        public double getBudget(){
            return budget;
        }
        public double getHours(){
            return hoursUsed;
        }
}
