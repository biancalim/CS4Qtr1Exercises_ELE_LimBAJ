class Main {
  public static void main(String[] args) {

    //object 1
    
    String objectName = "Headphones";
    double aveHoursUsed = 7.5;
    int monthsOwned = 1;

    //object 2

    String objectName2 = "Glasses";
    double aveHoursUsed2 = 5.5;
    int monthsOwned2 = 24;

    //object 3

    String objectName3 = "Electric Fan";
    double aveHoursUsed3 = 12.5;
    int monthsOwned3 = 36;


         System.out.println(' ');

    System.out.println("Object 1");
    System.out.println("Name: " + objectName);
    System.out.println("Average number of hours used in a day: " + aveHoursUsed);
    System.out.println("Number of Months Owned: " + monthsOwned);

     System.out.println(' ');

     System.out.println("Object 2");
    System.out.println("Name: " + objectName2);
    System.out.println("Average number of hours used in a day: " + aveHoursUsed2);
    System.out.println("Number of Months Owned: " + monthsOwned2);

        System.out.println(' ');

     System.out.println("Object 3");
    System.out.println("Name: " + objectName3);
    System.out.println("Average number of hours used in a day: " + aveHoursUsed3);
    System.out.println("Number of Months Owned: " + monthsOwned3);

         System.out.println(' ');

        double difference = aveHoursUsed - aveHoursUsed2;
    
    System.out.println("Number of hours that object 1 is used more than object 2: " + difference + " hours");

    boolean comparison = aveHoursUsed2 < aveHoursUsed3;

      System.out.println("Object 3 is older than Object 2: " + comparison);

    int sum = monthsOwned + monthsOwned2 + monthsOwned3;

    System.out.println("Total number of months all these objects are owned: " + sum + " months!");
    

    
    
    
    
  }

}