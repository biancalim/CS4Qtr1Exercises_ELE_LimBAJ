/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rockpaperscissors;

/**
 *
 * @author Bianca
 */

//EX04_ELE_LimBAJ
import java.util.Scanner;

public class EX04_ELE_LimBAJ {

   public static void main(String[] args){
       
       
		Move rock = new Move("Rock");
		Move paper = new Move("Paper");
		Move scissors = new Move("Scissors");
		
		rock.setStrongAgainst(scissors);
		paper.setStrongAgainst(rock);
		scissors.setStrongAgainst(paper);
		
		int roundsToWin = 2;
                int compMoves = 0;
                int roundsLost = 0;
                int roundsWon = 0;
                int answer = 0;
                String value;
                int random;
                
                random = (int)Math.floor(Math.random()*3)+1;
                
                do{
                    
                     do{
                    System.out.println(' ');
                System.out.println("Welcome to Rock, Paper Scissors!");
                System.out.println("Please choose an option: ");
                System.out.println("1. Start game");
                System.out.println("2. Change number of rounds");
                System.out.println("3. Exit the application");
                
                System.out.println(' ');
                
                System.out.print("Input option here: ");
                System.out.println(' ');
                
                Scanner an = new Scanner(System.in);
                answer = an.nextInt();
                } while(answer < 1 || answer > 3);
                
                    if(answer == 1){
                        do{
                            System.out.println(' ');
                        System.out.println("Let's start the game.");
                        System.out.println("Please input the letter of your chosen answer:");
                        System.out.println("a. Rock");
                        System.out.println("b. Paper");
                        System.out.println("c. Scissors");
                        
                        Scanner val = new Scanner(System.in);
                        value = val.nextLine();
                        
                        
                            switch(value){
                             case "a":
                                switch(random){
                                    case 1:
                                        compMoves = Move.compareMoves(rock, rock);
                                        break;
                                    case 2:
                                        compMoves = Move.compareMoves(rock, paper);
                                        break;
                                    case 3:
                                    compMoves = Move.compareMoves(rock, scissors);
                                    break;
                                }
                                
                                break;
                                
                                case "b":
                                switch (random){
                                    case 1:
                                        compMoves = Move.compareMoves(paper, rock);
                                        break;
                                    case 2:
                                        compMoves = Move.compareMoves(paper, paper);
                                        break;
                                    case 3:
                                        compMoves = Move.compareMoves(paper, scissors);
                                    break;
                                }
                                
                                case "c":
                                switch (random){
                                    case 1:
                                        compMoves = Move.compareMoves(scissors, rock);
                                        break;
                                    case 2:
                                        compMoves = Move.compareMoves(scissors, paper);
                                        break;
                                    case 3:
                                    compMoves = Move.compareMoves(scissors, scissors);
                                    break;
                                }
                                
                                break;
                                
                                default:
                                    System.out.println("Invalid input! Run again");
                                    
                        }
                        
                                
                       
                    if(compMoves == 0){
                    roundsWon = roundsWon + 1;
                    System.out.println("You have Won! This is the number of rounds you achieved: " + roundsWon);
                    System.out.println("This is how many rounds the computer has lost: " + roundsWon);
                    } 
                    
                    else if (compMoves == 1){
                    roundsLost = roundsLost + 1;
                    System.out.println("The computer has won! You have lost this number of rounds: " + roundsLost);
                    System.out.println("This is how many rounds the computer has won: " + roundsLost);
                    } 
                    
                    else if (compMoves == 2){
                    System.out.println("It's a tie. Neither you nor the computer has won.");
                    }
                        }while(roundsWon < roundsToWin);
                        
                   
                    } 
                   
                     if(answer == 2){
                        System.out.println("You will change the number of rounds");
                        System.out.print("Please input here: ");
                        Scanner nR = new Scanner (System.in);
                        int newRoundNo = nR.nextInt();
                        roundsToWin = newRoundNo;
                        System.out.println("New settings has been saved!");
                        continue;
                    }
                     
                     if(answer == 3){
                         System.out.println("Game will be exited.");
                         break;
                     }
 
                }while(roundsWon < roundsToWin);
                    
              
   }
                
                    
                    
}

